# Bibliometa
Sistema acadêmico bibliotecario simples 
Estrutura responsavel pela base e organização do sistema


## Para criar a venv na sua maquina
Crie um ambiente virtual (altamente recomendado):
```python -m venv venv```

Ative o ambiente virtual:

- Windows: ```.\venv\Scripts\activate```
- Linux: ```source venv/bin/activate```

Instale as dependências:

```pip install -r requirements.txt```

Execute a aplicação Flask:
```python main.py```