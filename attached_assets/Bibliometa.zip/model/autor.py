from pessoa import Pessoa
class Autor(Pessoa):
    def __init__(self, nacionalidade, livros):
        super().__init__(nome)
        self.nacionalidade = nacionalidade
        self.livros = []
    