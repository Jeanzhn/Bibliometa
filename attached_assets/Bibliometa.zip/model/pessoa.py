class Pessoa:
    def __init__(self, nome, email, tipo):
        self.nome = nome
        self.email = email
        self.tipo = tipo #membro, admin etc...
        
